from lwk.models.user_profile import UserProfile
#from models.user_profile import UserProfile

def load_profiles(
    file_path: str = "config/users.json",
) -> list[UserProfile]:

    path = Path(file_path)

    with open(
        path,
        encoding="utf-8",
    ) as f:

        data = json.load(f)

    profiles = []

    for user in data["users"]:

        profiles.append(
            UserProfile(
                name=user["name"],
                telegram_id=user["telegram_id"],
                cities=user.get("cities", []),
                min_salary=user.get("min_salary"),
                required_visas=user.get(
                    "required_visas",
                    [],
                ),
                keywords=user.get(
                    "keywords",
                    [],
                ),
            )
        )

    return profiles